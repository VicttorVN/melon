from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.auth.dependencies import require_participante
from . import services

router = APIRouter(prefix="/empresa", tags=["empresa"])

@router.get("/me/dre")
def dre(current_user = Depends(require_participante), db: Session = Depends(get_db)):
    return services.get_dre(current_user, db)

@router.get("/me/balanco")
def balanco(current_user = Depends(require_participante), db: Session = Depends(get_db)):
    return services.get_balanco(current_user, db)

@router.get("/me/fluxo-caixa")
def fluxo(current_user = Depends(require_participante), db: Session = Depends(get_db)):
    return services.get_fluxo_caixa(current_user, db)

@router.get("/me/estoque")
def estoque(current_user = Depends(require_participante), db: Session = Depends(get_db)):
    return services.get_estoque(current_user, db)

@router.get("/me/historico")
def historico(current_user = Depends(require_participante), db: Session = Depends(get_db)):
    return services.get_historico(current_user, db)

@router.get("/me/posicao")
def posicao(current_user = Depends(require_participante), db: Session = Depends(get_db)):
    return services.get_ranking(current_user, db)