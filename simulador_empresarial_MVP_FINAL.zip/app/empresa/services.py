def get_dre(user, db):
    # Suponha que exista tabela DRE associada à empresa_id
    return db.query(DRE).filter(DRE.empresa_id == user.empresa_id).all()

def get_balanco(user, db):
    return db.query(Balanco).filter(Balanco.empresa_id == user.empresa_id).first()

def get_fluxo_caixa(user, db):
    return db.query(FluxoCaixa).filter(FluxoCaixa.empresa_id == user.empresa_id).all()

def get_estoque(user, db):
    return db.query(Estoque).filter(Estoque.empresa_id == user.empresa_id).all()

def get_historico(user, db):
    return db.query(RodadaHistorico).filter(RodadaHistorico.empresa_id == user.empresa_id).all()

def get_ranking(user, db):
    # Suponha que ranking seja baseado no patrimônio líquido
    empresas = db.query(Empresa).order_by(Empresa.patrimonio.desc()).all()
    for i, empresa in enumerate(empresas):
        if empresa.id == user.empresa_id:
            return {"posicao": i + 1, "total_empresas": len(empresas)}
    return {"posicao": None}