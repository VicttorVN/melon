from sqlalchemy import Column, Float
from app.database import Base

class ParametrosMercado(Base):
    __tablename__ = "parametros_mercado"

    id = Column(Float, primary_key=True, default=1)
    inflacao = Column(Float, default=5.0)
    juros = Column(Float, default=10.0)
    preco_materia_prima = Column(Float, default=100.0)
    preco_maquinas = Column(Float, default=10000.0)
    custo_propaganda = Column(Float, default=500.0)
    imposto_renda = Column(Float, default=15.0)
    crescimento_economico = Column(Float, default=2.5)