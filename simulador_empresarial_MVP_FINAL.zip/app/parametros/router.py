from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.auth.dependencies import require_admin
from . import services, schemas

router = APIRouter(prefix="/admin/parametros", tags=["admin"])

@router.get("/", response_model=schemas.ParametrosOut)
def ver_parametros(db: Session = Depends(get_db), admin=Depends(require_admin)):
    return services.get_parametros(db)

@router.put("/", response_model=schemas.ParametrosOut)
def atualizar_parametros(update: schemas.ParametrosUpdate, db: Session = Depends(get_db), admin=Depends(require_admin)):
    return services.update_parametros(db, update)