from sqlalchemy.orm import Session
from .models import ParametrosMercado
from .schemas import ParametrosUpdate

def get_parametros(db: Session):
    params = db.query(ParametrosMercado).first()
    if not params:
        params = ParametrosMercado()
        db.add(params)
        db.commit()
        db.refresh(params)
    return params

def update_parametros(db: Session, novos_parametros: ParametrosUpdate):
    params = get_parametros(db)
    for field, value in novos_parametros.dict().items():
        setattr(params, field, value)
    db.commit()
    db.refresh(params)
    return params