from pydantic import BaseModel

class ParametrosBase(BaseModel):
    inflacao: float
    juros: float
    preco_materia_prima: float
    preco_maquinas: float
    custo_propaganda: float
    imposto_renda: float
    crescimento_economico: float

class ParametrosUpdate(ParametrosBase):
    pass

class ParametrosOut(ParametrosBase):
    pass