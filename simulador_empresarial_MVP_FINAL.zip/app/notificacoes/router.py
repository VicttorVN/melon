from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.auth.dependencies import require_admin
from . import schemas, services

router = APIRouter(prefix="/admin/notificacoes", tags=["notificacoes"])

@router.post("/", response_model=schemas.NotificacaoOut)
def enviar_notificacao(data: schemas.NotificacaoCreate, db: Session = Depends(get_db), admin=Depends(require_admin)):
    return services.simular_envio(data, db)

@router.get("/", response_model=list[schemas.NotificacaoOut])
def listar_notificacoes(db: Session = Depends(get_db), admin=Depends(require_admin)):
    return services.listar_notificacoes(db)