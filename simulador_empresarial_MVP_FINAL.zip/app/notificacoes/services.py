from sqlalchemy.orm import Session
from .models import NotificacaoLog
from .schemas import NotificacaoCreate
from datetime import datetime

def simular_envio(notif: NotificacaoCreate, db: Session):
    log = NotificacaoLog(
        destinatario=notif.destinatario,
        assunto=notif.assunto,
        mensagem=notif.mensagem,
        data_envio=datetime.utcnow()
    )
    db.add(log)
    db.commit()
    db.refresh(log)
    return log

def listar_notificacoes(db: Session):
    return db.query(NotificacaoLog).order_by(NotificacaoLog.data_envio.desc()).all()