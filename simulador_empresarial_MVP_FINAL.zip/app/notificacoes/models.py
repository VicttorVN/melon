from sqlalchemy import Column, Integer, String, DateTime
from datetime import datetime
from app.database import Base

class NotificacaoLog(Base):
    __tablename__ = "notificacoes_log"

    id = Column(Integer, primary_key=True)
    destinatario = Column(String, nullable=False)
    assunto = Column(String, nullable=False)
    mensagem = Column(String, nullable=False)
    data_envio = Column(DateTime, default=datetime.utcnow)