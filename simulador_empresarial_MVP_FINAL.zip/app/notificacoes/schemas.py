from pydantic import BaseModel, EmailStr

class NotificacaoCreate(BaseModel):
    destinatario: EmailStr
    assunto: str
    mensagem: str

class NotificacaoOut(NotificacaoCreate):
    data_envio: str