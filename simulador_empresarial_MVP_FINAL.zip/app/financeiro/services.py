def get_estoque_atual(empresa_id: int, db: Session):
    return db.query(Estoque).filter(Estoque.empresa_id == empresa_id).order_by(Estoque.rodada.desc()).first()

def get_fluxo_caixa(empresa_id: int, db: Session):
    return db.query(FluxoCaixa).filter(FluxoCaixa.empresa_id == empresa_id).order_by(FluxoCaixa.rodada.desc()).all()