from pydantic import BaseModel

class EstoqueOut(BaseModel):
    rodada: int
    materia_prima: int
    produto_acabado: int

    class Config:
        orm_mode = True

class FluxoCaixaOut(BaseModel):
    rodada: int
    entrada: float
    saida: float
    saldo: float

    class Config:
        orm_mode = True