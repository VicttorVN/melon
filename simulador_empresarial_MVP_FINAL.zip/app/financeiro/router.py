from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.auth.dependencies import require_participante
from . import services, schemas

router = APIRouter(prefix="/empresa/me", tags=["financeiro"])

@router.get("/estoque", response_model=schemas.EstoqueOut)
def estoque(user = Depends(require_participante), db: Session = Depends(get_db)):
    return services.get_estoque_atual(user.empresa_id, db)

@router.get("/fluxo-caixa", response_model=list[schemas.FluxoCaixaOut])
def fluxo_caixa(user = Depends(require_participante), db: Session = Depends(get_db)):
    return services.get_fluxo_caixa(user.empresa_id, db)