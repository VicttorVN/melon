from sqlalchemy import Column, Integer, Float, ForeignKey
from app.database import Base

class Estoque(Base):
    __tablename__ = "estoques"
    id = Column(Integer, primary_key=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id"))
    rodada = Column(Integer)
    materia_prima = Column(Integer, default=0)
    produto_acabado = Column(Integer, default=0)

class FluxoCaixa(Base):
    __tablename__ = "fluxo_caixa"
    id = Column(Integer, primary_key=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id"))
    rodada = Column(Integer)
    entrada = Column(Float, default=0.0)
    saida = Column(Float, default=0.0)
    saldo = Column(Float, default=0.0)