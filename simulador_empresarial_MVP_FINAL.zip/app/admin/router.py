from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.auth.dependencies import require_admin
from . import services

router = APIRouter(prefix="/admin", tags=["admin"])

@router.get("/empresas")
def listar_empresas(db: Session = Depends(get_db), user = Depends(require_admin)):
    return services.get_empresas(db)

@router.get("/empresas/{empresa_id}/participantes")
def listar_participantes(empresa_id: int, db: Session = Depends(get_db), user = Depends(require_admin)):
    return services.get_participantes(empresa_id, db)

@router.get("/rodadas")
def listar_rodadas(db: Session = Depends(get_db), user = Depends(require_admin)):
    return services.get_rodadas(db)

@router.post("/rodadas/{rodada_id}/fechar")
def fechar_rodada(rodada_id: int, db: Session = Depends(get_db), user = Depends(require_admin)):
    return services.fechar_rodada(rodada_id, db)

@router.get("/empresas/{empresa_id}/relatorios")
def relatorios_empresa(empresa_id: int, db: Session = Depends(get_db), user = Depends(require_admin)):
    return services.get_relatorios_empresa(empresa_id, db)