def get_empresas(db: Session):
    return db.query(Empresa).all()

def get_participantes(empresa_id: int, db: Session):
    return db.query(Usuario).filter(Usuario.empresa_id == empresa_id).all()

def get_rodadas(db: Session):
    return db.query(Rodada).all()

def fechar_rodada(rodada_id: int, db: Session):
    rodada = db.query(Rodada).filter(Rodada.id == rodada_id).first()
    if not rodada:
        raise HTTPException(status_code=404, detail="Rodada não encontrada")
    if rodada.status == "fechada":
        raise HTTPException(status_code=400, detail="Rodada já foi fechada")
    rodada.status = "fechada"
    db.commit()
    return {"msg": f"Rodada {rodada_id} foi fechada com sucesso."}

def get_relatorios_empresa(empresa_id: int, db: Session):
    # Exemplo simplificado
    relatorios = {
        "dre": {}, "balanco": {}, "fluxo_caixa": {}, "ranking": {}
    }
    # aqui pode puxar das tabelas já existentes no seu projeto
    return relatorios