const { body, validationResult } = require('express-validator');

const validateDecision = [
  body('preco').isFloat({ min: 0.01 }).withMessage('Preço inválido.'),
  body('salario').isFloat({ min: 500 }).withMessage('Salário mínimo é R$500.'),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ erros: errors.array() });
    }
    next();
  }
];

module.exports = validateDecision;