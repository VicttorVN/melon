const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.json({
    patrimonio: [
      { empresa: 'Empresa A', valores: [10000, 12500, 14000] },
      { empresa: 'Empresa B', valores: [8000, 9000, 12000] }
    ],
    lucro: [
      { empresa: 'Empresa A', valor: 2000 },
      { empresa: 'Empresa B', valor: 1500 },
      { empresa: 'Empresa C', valor: 2500 }
    ]
  });
});

module.exports = router;