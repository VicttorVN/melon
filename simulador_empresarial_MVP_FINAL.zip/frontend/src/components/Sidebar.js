export default function Sidebar() {
  return (
    <div className="w-64 bg-gray-900 text-white p-4 min-h-screen">
      <h2 className="text-2xl font-bold mb-4">Simulador</h2>
      <ul className="space-y-2">
        <li><a href="/home" className="block hover:bg-gray-700 p-2 rounded">Dashboard</a></li>
        <li><a href="#" className="block hover:bg-gray-700 p-2 rounded">Relatórios</a></li>
      </ul>
    </div>
  );
}