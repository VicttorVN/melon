import { Line, Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  LineElement,
  BarElement,
  CategoryScale,
  LinearScale,
  PointElement,
} from 'chart.js';

ChartJS.register(LineElement, BarElement, CategoryScale, LinearScale, PointElement);

const patrimonioData = {
  labels: ['Rodada 1', 'Rodada 2', 'Rodada 3'],
  datasets: [{
    label: 'Empresa A',
    data: [10000, 12500, 14000],
    borderColor: 'rgb(59,130,246)',
    tension: 0.4,
  }],
};

const lucroData = {
  labels: ['Empresa A', 'Empresa B', 'Empresa C'],
  datasets: [{
    label: 'Lucro',
    data: [2000, 1500, 2500],
    backgroundColor: 'rgb(16,185,129)',
  }],
};

export default function Dashboard() {
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Dashboard</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded shadow"><Line data={patrimonioData} /></div>
        <div className="bg-white p-4 rounded shadow"><Bar data={lucroData} /></div>
      </div>
    </div>
  );
}