from fastapi import FastAPI, Depends
from backend.database import engine, Base
from backend import models, simulador_logic
from auth.router import router as auth_router
from app.empresa.router import router as empresa_router
from app.parametros.router import router as parametros_router
from app.financeiro.router import router as financeiro_router
from app.notificacoes.router import router as notificacoes_router
from app.admin.router import router as admin_router
from app.auth.dependencies import require_admin

app = FastAPI()


@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)


app.include_router(empresa_router)
app.include_router(parametros_router)
app.include_router(financeiro_router)
app.include_router(notificacoes_router)
app.include_router(admin_router)
app.include_router(auth_router)


@app.get("/admin-only")
def rota_admin(current_user=Depends(require_admin)):
    return {"msg": "Bem-vindo, Admin!"}
