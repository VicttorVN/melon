# 💼 Simulador Empresarial – FastAPI + TailwindCSS

Simulador de decisões empresariais com múltiplas empresas e rodadas econômicas.  
Totalmente modular, seguro (JWT), responsivo e pronto para uso acadêmico.

## 🧠 Tecnologias
- FastAPI
- SQLAlchemy
- TailwindCSS
- JWT
- SQLite/PostgreSQL
- Chart.js (gráficos)
- Jinja2 (templates frontend)

---

## 📦 Funcionalidades Entregues

| Funcionalidade                             | Status |
|--------------------------------------------|--------|
| Cadastro de empresas/participantes         | ✅      |
| Painel Admin + fechamento de rodadas       | ✅      |
| Painel Empresa com relatórios privados     | ✅      |
| DRE, Balanço, Fluxo de Caixa, Estoque      | ✅      |
| Ranking e histórico de decisões            | ✅      |
| Parâmetros de mercado editáveis            | ✅      |
| Login JWT seguro + proteção por role       | ✅      |
| UI responsiva com TailwindCSS              | ✅      |
| Notificações fictícias com logs            | ✅      |
| Testes + documentação final                | ✅      |

---

## 🔐 Usuários de Teste

| Role         | Email                 | Senha     |
|--------------|-----------------------|-----------|
| Admin        | admin@simulador.com   | admin123  |
| Participante | user@empresa1.com     | user123   |

---

## ▶️ Como Rodar

```bash
uvicorn main:app --reload
