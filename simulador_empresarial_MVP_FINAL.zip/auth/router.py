from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.database import get_db
from . import schemas, services, utils, models
from fastapi.security import OAuth2PasswordRequestForm
from fastapi import HTTPException, status

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/register", response_model=schemas.UsuarioOut)
def registrar(usuario: schemas.UsuarioCreate, db: Session = Depends(get_db)):
    return services.criar_usuario(db, usuario)


@router.post("/login", response_model=schemas.Token)
def login(form_data: OAuth2PasswordRequestForm = Depends(),
          db: Session = Depends(get_db)):
    user = services.autenticar_usuario(db, form_data.username,
                                       form_data.password)
    token = utils.gerar_token({"sub": str(user.id), "role": user.role})
    return {"access_token": token, "token_type": "bearer"}
