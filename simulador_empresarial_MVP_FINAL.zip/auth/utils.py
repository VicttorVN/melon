from passlib.context import CryptContext
from datetime import datetime, timedelta
import jwt

SECRET_KEY = "seu_segredo_top_secreto"
ALGORITHM = "HS256"
ACESSO_MINUTOS = 120

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def gerar_hash(senha: str):
    return pwd_context.hash(senha)

def verificar_senha(senha: str, hash: str):
    return pwd_context.verify(senha, hash)

def gerar_token(dados: dict, expira_minutos: int = ACESSO_MINUTOS):
    to_encode = dados.copy()
    expire = datetime.utcnow() + timedelta(minutes=expira_minutos)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def decodificar_token(token: str):
    return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])