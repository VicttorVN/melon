from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from .utils import decodificar_token
from app.database import get_db
from .models import Usuario
from sqlalchemy.orm import Session

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")

def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> Usuario:
    payload = decodificar_token(token)
    user_id = int(payload.get("sub"))
    user = db.query(Usuario).filter(Usuario.id == user_id).first()
    if not user:
        raise HTTPException(status_code=401, detail="Usuário não encontrado")
    return user

def require_admin(current_user: Usuario = Depends(get_current_user)):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Acesso restrito")
    return current_user

def require_participante(current_user: Usuario = Depends(get_current_user)):
    if current_user.role != "participante":
        raise HTTPException(status_code=403, detail="Apenas participantes")
    return current_user