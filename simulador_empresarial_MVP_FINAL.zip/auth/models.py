from sqlalchemy import Column, Integer, String, ForeignKey
from app.database import Base

class Usuario(Base):
    __tablename__ = "usuarios"

    id = Column(Integer, primary_key=True, index=True)
    nome = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    senha_hash = Column(String, nullable=False)
    role = Column(String, default="participante")  # ou 'admin'
    empresa_id = Column(Integer, ForeignKey("empresas.id"))