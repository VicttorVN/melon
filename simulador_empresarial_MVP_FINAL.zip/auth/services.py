from sqlalchemy.orm import Session
from . import models, utils
from fastapi import HTTPException, status

def autenticar_usuario(db: Session, email: str, senha: str):
    user = db.query(models.Usuario).filter(models.Usuario.email == email).first()
    if not user or not utils.verificar_senha(senha, user.senha_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Credenciais inválidas")
    return user

def criar_usuario(db: Session, usuario_dados):
    hash = utils.gerar_hash(usuario_dados.senha)
    novo = models.Usuario(
        nome=usuario_dados.nome,
        email=usuario_dados.email,
        senha_hash=hash,
        role=usuario_dados.role
    )
    db.add(novo)
    db.commit()
    db.refresh(novo)
    return novo